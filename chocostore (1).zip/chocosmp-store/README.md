# ChocoStore (chocostore.id)

Web store yang otomatis membuat channel ticket pribadi di Discord setiap ada pesanan.

## Setup bot (sekali saja)
1. Buka https://discord.com/developers/applications, buat aplikasi, lalu tab **Bot**.
2. Aktifkan **Server Members Intent**, lalu salin token bot.
3. Undang bot ke servermu dengan izin: Manage Channels, View Channels, Send Messages, Manage Roles.
4. Buat satu kategori Discord untuk ticket. Pastikan role bot berada di atas role pembeli.
5. Aktifkan Developer Mode di Discord, lalu salin ID server, ID kategori, dan ID role admin (klik kanan, Copy ID).

## Jalankan
```
npm install
cp .env.example .env     # lalu isi semua nilainya
npm start
```
Buka http://localhost:3000. Untuk online, jalankan di VPS atau hosting Node.js dan arahkan domain ke port tersebut.

## Mengubah harga atau rank
Ubah di dua tempat dan samakan: `RANKS` di `public/index.html` dan `PRICES` di `server.js`.

Penting: jangan pernah membagikan file `.env` atau token bot.

## Memakai domain chocostore.id
1. Beli domain `chocostore.id` di registrar domain .id (cek dulu apakah namanya masih tersedia).
2. Setelah toko online di Render, buka pengaturan **Custom Domains** di service-nya dan tambahkan `chocostore.id`.
3. Di pengaturan DNS registrar, tambahkan record yang ditunjukkan Render, lalu tunggu aktif.
