require("dotenv").config();
const express = require("express");
const { Client, GatewayIntentBits, ChannelType, PermissionFlagsBits: P, EmbedBuilder } = require("discord.js");

// Harus sama dengan harga di public/index.html
const PRICES = {
  "Choco": 5000, "Choco+": 10000, "Choco++": 15000, "Choco+++": 20000, "CEO": 40000,
  "Guardian": 50000, "Guardian+": 70000, "Guardian++": 80000, "Guardian+++": 100000,
  "Donatur": 200000, "King": 230000, "Investor": 300000
};
const PAYMENTS = ["QRIS", "Transfer bank", "DANA", "GoPay", "OVO"];

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers] });
const app = express();
app.set("trust proxy", 1);
app.use(express.json({ limit: "2kb" }));
app.use(express.static("public"));

const hits = new Map(); // batas 3 pesanan / 10 menit / IP
function limited(ip) {
  const now = Date.now();
  const a = (hits.get(ip) || []).filter(t => now - t < 600000);
  a.push(now); hits.set(ip, a);
  return a.length > 3;
}

app.post("/api/order", async (req, res) => {
  try {
    if (limited(req.ip)) return res.status(429).json({ error: "Terlalu banyak pesanan. Coba lagi 10 menit lagi." });
    const { rank, ign, discord, pay } = req.body || {};
    const price = PRICES[rank];
    if (!price) return res.status(400).json({ error: "Rank tidak valid." });
    if (!/^\.?[A-Za-z0-9_ ]{3,16}$/.test(ign || "")) return res.status(400).json({ error: "Nama Minecraft tidak valid." });
    if (!/^[a-z0-9_.]{2,32}$/i.test(discord || "")) return res.status(400).json({ error: "Username Discord tidak valid." });
    if (!PAYMENTS.includes(pay)) return res.status(400).json({ error: "Metode pembayaran tidak valid." });

    const guild = await client.guilds.fetch(process.env.GUILD_ID);
    const found = await guild.members.search({ query: discord, limit: 10 });
    const member = found.find(m => m.user.username.toLowerCase() === discord.toLowerCase());
    if (!member) return res.status(404).json({ error: "Username Discord tidak ditemukan di server. Pastikan kamu sudah join dan ejaannya benar." });

    const code = Math.random().toString(36).slice(2, 6);
    const channel = await guild.channels.create({
      name: `order-${ign.replace(/[^a-z0-9_]/gi, "").toLowerCase() || "pemain"}-${code}`,
      type: ChannelType.GuildText,
      parent: process.env.CATEGORY_ID || null,
      permissionOverwrites: [
        { id: guild.roles.everyone.id, deny: [P.ViewChannel] },
        { id: member.id, allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles] },
        { id: process.env.STAFF_ROLE_ID, allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.ManageChannels] },
        { id: client.user.id, allow: [P.ViewChannel, P.SendMessages, P.ManageChannels] }
      ]
    });

    const embed = new EmbedBuilder()
      .setTitle("Pesanan rank baru")
      .setColor(0x7FE0C3)
      .addFields(
        { name: "Rank", value: rank, inline: true },
        { name: "Harga", value: "Rp" + price.toLocaleString("id-ID"), inline: true },
        { name: "Pembayaran", value: pay, inline: true },
        { name: "Nama Minecraft", value: "`" + ign + "`", inline: true },
        { name: "Discord", value: `<@${member.id}>`, inline: true }
      )
      .setFooter({ text: "Admin akan mengirim detail pembayaran di sini." });
    await channel.send({ content: `<@${member.id}> <@&${process.env.STAFF_ROLE_ID}>`, embeds: [embed] });

    res.json({ ok: true, channel: "#" + channel.name });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Terjadi kesalahan di server. Coba lagi nanti." });
  }
});

client.once("ready", () => {
  console.log("Bot online sebagai " + client.user.tag);
  app.listen(process.env.PORT || 3000, () => console.log("Web store jalan di port " + (process.env.PORT || 3000)));
});
client.login(process.env.DISCORD_TOKEN);
